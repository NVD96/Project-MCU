#include <mega328p.h>
#include <delay.h>
#include <spi.h>
#include "uart.h"
void main(void)
{
#pragma optsize-
CLKPR=0x80;
CLKPR=0x00;
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

PORTB=0xff;
DDRB=0xff;
DDRB.4=0;

PORTC=0xff;
DDRC=0xff;

PORTD=0xff;
DDRD=0xff;

// SPI initialization
// SPI Type: Master
// SPI Clock Rate: 4000,000 kHz
// SPI Clock Phase: Cycle Start
// SPI Clock Polarity: Low
// SPI Data Order: MSB First
SPCR=0x50;
SPSR=0x00;

UART_init();
#asm("sei")

UART_putString("IOT47.com - ENC28J60 tutorial !!!\r\n");

while (1)
      {


      }
}
