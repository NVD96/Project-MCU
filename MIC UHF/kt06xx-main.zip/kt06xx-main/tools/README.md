## KT061x & KT062x 配置软件

 - Wireless Mic Rx Configuration
 - Wireless Mic Tx(KT062x) Configuration
 
下载整个文件夹后可直接双击执行。资料来自CSDN。
