this program writen by Cartiman for program-plc.blogspot.com
No sell and No Complaint