#include "tcp.h"
extern const uint8_t macaddr[6];
extern const uint8_t ip[4];
extern uint8_t debug_string[60];


uint16_t TCP_checksum(TCP_struct *TCP_Struct_Frame)
{
   uint32_t checksum;
   uint8_t *ptr;
   uint16_t length;
   length = swap16(TCP_Struct_Frame->TotoLength) - 20 + 8 ; //tinh length bat dau tu checksum
   ptr = (uint8_t *)&TCP_Struct_Frame->SourceIP;       //dia chi bat dau tinh checksum

   checksum=6 + length - 8;
   while(length>1) //cong het cac byte16 lai
    {
       checksum += (uint16_t) (((uint32_t)*ptr<<8)|*(ptr+1));
       ptr+=2;
       length-=2;
    };
    if(length) checksum+=((uint32_t)*ptr)<<8; //neu con le 1 byte
    while (checksum>>16) checksum=(uint16_t)checksum+(checksum>>16);
    //nghich dao bit
    checksum=~checksum;
    //hoan vi byte thap byte cao
    return swap16(checksum);
}
void TCP_read(uint8_t *TCP_Frame,uint16_t len)
{
  uint32_t dat_ack;
  uint16_t port;
  TCP_struct *TCP_Struct_Frame = (TCP_struct *)TCP_Frame;
  //kiem tra dia chi ip xem co phai no gui cho minh khong
  if( memcmp(TCP_Struct_Frame->DestIP,ip,4) )return; // dung memcmp de so sanh, neu khac thi thoat
  if(TCP_Struct_Frame->TCP_Flags == TCP_SYN)
  {
     //reply voi SYN|ACK
     //make reply
     memcpy(TCP_Struct_Frame->MAC_dich,TCP_Struct_Frame->MAC_nguon,6);
     memcpy(TCP_Struct_Frame->MAC_nguon,macaddr,6);
     TCP_Struct_Frame->CheckSum=0;
     memcpy(TCP_Struct_Frame->DestIP,TCP_Struct_Frame->SourceIP,4); //hoan vi source, dest
     memcpy(TCP_Struct_Frame->SourceIP,ip,4);                       //ip cua minh
     port = TCP_Struct_Frame->Source_Port;
     TCP_Struct_Frame->Source_Port = TCP_Struct_Frame->Dest_Port;
     TCP_Struct_Frame->Dest_Port = port;
     TCP_Struct_Frame->Acknowledgement = swap32(swap32(TCP_Struct_Frame->Sequence_Number) + 1);
     TCP_Struct_Frame->Sequence_Number = swap32(2071998);
     TCP_Struct_Frame->TCP_Flags = TCP_SYN | TCP_ACK;
     TCP_Struct_Frame->TCP_Checksums=0;
     TCP_Struct_Frame->Urgent_Pointer=0;
     TCP_Struct_Frame->CheckSum = NET_ipchecksum((uint8_t *)&TCP_Struct_Frame->Header_length);  //tinh checksum cho goi IO
     TCP_Struct_Frame->TCP_Checksums = TCP_checksum(TCP_Struct_Frame);

     NET_SendFrame((uint8_t *)TCP_Struct_Frame,len); //gui goi tin tcp reply
  }
  else if(TCP_Struct_Frame->TCP_Flags == TCP_ACK)
  {
     UART_putString("Ack\r\n");
  }
  else if(TCP_Struct_Frame->TCP_Flags == (TCP_FIN|TCP_ACK))
  {
     //reply voi ACK
     //make reply
     memcpy(TCP_Struct_Frame->MAC_dich,TCP_Struct_Frame->MAC_nguon,6);
     memcpy(TCP_Struct_Frame->MAC_nguon,macaddr,6);
     TCP_Struct_Frame->CheckSum=0;
     memcpy(TCP_Struct_Frame->DestIP,TCP_Struct_Frame->SourceIP,4); //hoan vi source, dest
     memcpy(TCP_Struct_Frame->SourceIP,ip,4);                       //ip cua minh
     port = TCP_Struct_Frame->Source_Port;
     TCP_Struct_Frame->Source_Port = TCP_Struct_Frame->Dest_Port;
     TCP_Struct_Frame->Dest_Port = port;
     dat_ack =  TCP_Struct_Frame->Acknowledgement;
     TCP_Struct_Frame->Acknowledgement = swap32(swap32(TCP_Struct_Frame->Sequence_Number) + 1);
     TCP_Struct_Frame->Sequence_Number =   dat_ack;
     TCP_Struct_Frame->TCP_Flags = TCP_ACK;
     TCP_Struct_Frame->TCP_Checksums=0;
     TCP_Struct_Frame->Urgent_Pointer=0;
     TCP_Struct_Frame->CheckSum = NET_ipchecksum((uint8_t *)&TCP_Struct_Frame->Header_length);  //tinh checksum cho goi IO
     TCP_Struct_Frame->TCP_Checksums = TCP_checksum(TCP_Struct_Frame);

     NET_SendFrame((uint8_t *)TCP_Struct_Frame,len); //gui goi tin tcp reply

     TCP_Struct_Frame->TCP_Flags = TCP_FIN|TCP_ACK;
     TCP_Struct_Frame->TCP_Checksums=0;
     TCP_Struct_Frame->TCP_Checksums = TCP_checksum(TCP_Struct_Frame);

     NET_SendFrame((uint8_t *)TCP_Struct_Frame,len); //gui goi tin tcp reply
  }
}


//--------------------------------------------------
//end file
